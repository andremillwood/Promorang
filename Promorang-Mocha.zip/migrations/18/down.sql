
DROP TABLE user_achievements;
DROP TABLE achievements;
DROP TABLE content_engagement_tracking;
DROP TABLE drop_submissions;
DROP TABLE gold_purchases;
DROP TABLE referral_rewards;

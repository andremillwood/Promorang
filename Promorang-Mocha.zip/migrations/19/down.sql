
DROP INDEX idx_withdrawal_requests_status;
DROP INDEX idx_withdrawal_requests_user_id;
DROP INDEX idx_user_payment_preferences_user_id;
DROP TABLE withdrawal_methods;
DROP TABLE withdrawal_requests;
DROP TABLE user_payment_preferences;

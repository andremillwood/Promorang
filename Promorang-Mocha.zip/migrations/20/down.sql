
DELETE FROM withdrawal_methods;

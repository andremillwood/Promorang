
DROP INDEX idx_influence_rewards_platform;
DROP INDEX idx_influence_rewards_user_month;
DROP TABLE influence_rewards;


DROP TABLE economic_metrics;
DROP TABLE staking_rewards;
DROP TABLE growth_hub_analytics;
DROP TABLE shield_claims;
DROP TABLE shield_subscriptions;
DROP TABLE social_shield_policies;
DROP TABLE funding_pledges;
DROP TABLE funding_projects;
DROP TABLE staking_positions;
DROP TABLE growth_channels;

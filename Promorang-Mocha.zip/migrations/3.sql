
-- Update content pieces with proper media URLs
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=600&h=600&fit=crop' WHERE id = 1;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1516251193007-45ef944ab0c6?w=600&h=600&fit=crop' WHERE id = 2;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1556155092-490a1ba16284?w=600&h=600&fit=crop' WHERE id = 3;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1558403194-611308249627?w=600&h=600&fit=crop' WHERE id = 4;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?w=600&h=600&fit=crop' WHERE id = 5;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&h=600&fit=crop' WHERE id = 6;
UPDATE content_pieces SET media_url = 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=600&h=600&fit=crop' WHERE id = 7;

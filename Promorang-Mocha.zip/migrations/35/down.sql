
DELETE FROM drops WHERE title LIKE '[Demo]%' OR title = 'Complete Social Media Survey';

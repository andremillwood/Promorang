
DROP INDEX IF EXISTS idx_comment_likes_user;
DROP INDEX IF EXISTS idx_comment_likes_comment;
DROP TABLE IF EXISTS comment_likes;


DROP INDEX idx_uploaded_images_user_id;
DROP TABLE uploaded_images;

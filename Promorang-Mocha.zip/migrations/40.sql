
ALTER TABLE users ADD COLUMN brand_name TEXT;
ALTER TABLE users ADD COLUMN brand_logo_url TEXT;
ALTER TABLE users ADD COLUMN brand_description TEXT;
ALTER TABLE users ADD COLUMN brand_website TEXT;
ALTER TABLE users ADD COLUMN brand_email TEXT;
ALTER TABLE users ADD COLUMN brand_phone TEXT;

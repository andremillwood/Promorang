
ALTER TABLE users DROP COLUMN brand_phone;
ALTER TABLE users DROP COLUMN brand_email;
ALTER TABLE users DROP COLUMN brand_website;
ALTER TABLE users DROP COLUMN brand_description;
ALTER TABLE users DROP COLUMN brand_logo_url;
ALTER TABLE users DROP COLUMN brand_name;

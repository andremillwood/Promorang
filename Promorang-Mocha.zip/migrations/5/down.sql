
ALTER TABLE points_transactions DROP COLUMN user_level;
ALTER TABLE points_transactions DROP COLUMN multiplier;  
ALTER TABLE points_transactions DROP COLUMN base_points;
DROP TABLE content_shares;
DROP TABLE advertiser_analytics;
DROP TABLE user_level_upgrades;
DROP TABLE instagram_registrations;
DROP TABLE social_connections;

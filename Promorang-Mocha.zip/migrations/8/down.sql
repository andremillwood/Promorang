
ALTER TABLE users DROP COLUMN social_links;
ALTER TABLE users DROP COLUMN website_url;
ALTER TABLE users DROP COLUMN banner_url;
